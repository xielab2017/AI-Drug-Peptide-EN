# AI-Drug Peptide V1.0 - System Documentation

## 📋 Project Overview

**AI-Drug Peptide V1.0** is an AI-driven peptide drug development platform that uses a multi-step bioinformatics analysis pipeline to identify potential receptors from protein interaction networks, perform molecular docking predictions, assess cross-species conservation, and generate optimized peptide drug candidates.

## 🏗️ System Architecture

### Core Components

#### 1. **Four-Step Analysis Pipeline**
- **Step 1**: STRING Interaction Analysis (`bin/step1_string_interaction.py`)
- **Step 2**: Molecular Docking Prediction (`bin/step2_docking_prediction.py`)
- **Step 3**: Conservation Analysis (`bin/step3_conservation_check.py`)
- **Step 4**: Result Integration (`bin/step4_merge_results.py`)

#### 2. **Specialized Analysis Modules**
- **Secretion Analysis**: `bin/secretion_analysis.py`
- **Peptide Optimization**: `bin/peptide_optim.py`
- **Workflow Management**: `bin/workflow.py`

#### 3. **User Interface**
- **Command Line Interface**: `launch.py`
- **Web Dashboard**: `dashboard.py`
- **Installation Script**: `install.py`

#### 4. **Data Management**
- **Data Fetching**: `bin/data_fetch_robust.py`
- **Report Generation**: `bin/report_generator.py`
- **Visualization**: `bin/visual_dashboard.py`

## 🔧 Technology Stack

### Backend Technologies
- **Python 3.8+**: Primary programming language
- **Prefect**: Workflow management framework
- **Pandas/NumPy**: Data processing
- **BioPython**: Bioinformatics tools
- **SQLAlchemy**: Database ORM
- **Neo4j**: Graph database

### Frontend Technologies
- **Prefect UI**: Web dashboard
- **Plotly**: Data visualization
- **HTML/CSS/JavaScript**: Report generation

### Deployment Technologies
- **Docker**: Containerized deployment
- **GitHub Actions**: CI/CD pipeline
- **PyPI**: Python package distribution

## 📊 Data Flow

### Input Data
1. **Target Protein ID**: User-specified protein identifier
2. **Configuration Parameters**: Analysis parameters and threshold settings
3. **Database Connections**: STRING, NCBI, PDB databases

### Processing Pipeline
1. **Data Acquisition**: Fetch relevant data from multiple biological databases
2. **Interaction Analysis**: Identify protein-protein interaction networks
3. **Molecular Docking**: Predict binding affinity and binding sites
4. **Conservation Analysis**: Assess cross-species conservation
5. **Result Integration**: Comprehensive scoring and ranking

### Output Results
1. **Analysis Reports**: JSON, Excel, PDF, HTML formats
2. **Visualization Charts**: Interaction networks, conservation heatmaps
3. **Optimized Peptides**: Candidate drug molecule lists
4. **Log Files**: Detailed execution records

## 🚀 Installation and Deployment

### System Requirements
- **Operating System**: macOS 10.14+, Windows 10+, Ubuntu 18.04+
- **Python**: Version 3.8 or higher
- **Memory**: 4GB RAM (8GB+ recommended)
- **Storage**: 2GB available space
- **Network**: Stable internet connection

### Installation Methods

#### 1. One-line Installation
```bash
# macOS/Linux
curl -fsSL https://raw.githubusercontent.com/xielab2017/AI-Drug-Peptide-EN/main/install.sh | bash

# Windows (PowerShell)
Invoke-WebRequest -Uri "https://raw.githubusercontent.com/xielab2017/AI-Drug-Peptide-EN/main/install.ps1" -OutFile "install.ps1"
.\install.ps1
```

#### 2. Manual Installation
```bash
git clone https://github.com/xielab2017/AI-Drug-Peptide-EN.git
cd AI-Drug-Peptide-EN
python install.py
```

#### 3. Docker Deployment
```bash
docker-compose up -d
```

## 🔍 Usage Guide

### Quick Start
```bash
# Start application
python launch.py

# Run complete workflow
python launch.py --workflow --protein-id THBS4

# Start web dashboard
python dashboard.py
```

### Command Line Arguments
- `--workflow`: Run complete workflow
- `--steps`: Run specified steps
- `--protein-id`: Target protein ID
- `--dashboard`: Start web dashboard

### Configuration Files
- `config/config.json`: Main configuration file
- `config/config.yaml`: YAML format configuration
- `config/report_config.json`: Report configuration

## 📈 Performance Optimization

### Parallel Processing
- Multi-threaded data fetching
- Parallel molecular docking calculations
- Distributed workflow execution

### Caching Mechanisms
- Database query caching
- Computation result caching
- Intermediate file caching

### Memory Management
- Large dataset chunk processing
- Memory usage monitoring
- Garbage collection optimization

## 🔒 Security Considerations

### Data Security
- Local data processing
- Sensitive information encryption
- Access permission control

### Network Security
- HTTPS connections
- API key management
- Firewall configuration

## 🐛 Troubleshooting

### Common Issues
1. **Installation Failure**: Check Python version and network connection
2. **Missing Dependencies**: Run `python install.py --check-deps`
3. **Database Connection**: Check database service status
4. **Insufficient Memory**: Adjust memory limits in configuration files

### Log Viewing
```bash
# View application logs
tail -f logs/app.log

# View error logs
grep ERROR logs/app.log
```

## 📚 Development Guide

### Code Structure
```
AI-Drug-Peptide/
├── bin/                 # Core analysis scripts
├── src/                 # Source code modules
├── config/              # Configuration files
├── data/                # Data directory
├── logs/                # Log files
├── reports/             # Generated reports
└── tests/               # Test files
```

### Development Environment Setup
```bash
# Install development dependencies
python install.py --dev

# Run tests
python -m pytest tests/

# Code formatting
black src/
```

### Contribution Guidelines
- Follow PEP 8 coding standards
- Write unit tests
- Update documentation
- Submit Pull Requests

## 📞 Technical Support

### Contact Information
- **GitHub Issues**: https://github.com/xielab2017/AI-Drug-Peptide/issues
- **GitHub Discussions**: https://github.com/xielab2017/AI-Drug-Peptide/discussions
- **Email**: xielw@gdim.cn

### Documentation Resources
- **Project Documentation**: https://github.com/xielab2017/AI-Drug-Peptide
- **API Documentation**: Check `docs/` directory
- **Example Code**: Check `examples/` directory

## 📄 License

This project is licensed under the MIT License. See [LICENSE](LICENSE) file for details.

## 🙏 Acknowledgments

Thanks to all contributors and the open-source community!

---

**Version**: V1.0.0  
**Last Updated**: October 5, 2024  
**Maintainer**: AI-Drug Peptide Team